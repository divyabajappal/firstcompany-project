import static org.junit.Assert.*;
import org.junit.Test;
public class CalculatorTest 
{
	Calculator cal=new Calculator();
	@Test  //Used to identify that a method is a test method

	public void testSquares()
	{
		
		assertEquals(25,cal.square(5));
		assertEquals(5*5,cal.square(5));
		
	}
	
	@Test
	public void testUser()
	{
		assertEquals("sandip",cal.user("sandip"));
	}

	@Test
	public void stringtest()
	{
	String result = cal.concat("Hello", "World");
	assertEquals("HelloWorld", result);
	String s1="Hello";
	String s2="Hello";
	String s3 = new String("Hello");

	assertSame(s1,s2); //2 objects refers to same location?
	}
	
	
}