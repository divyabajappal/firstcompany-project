import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

import org.junit.Test; 
public class database1test 
{
	database1 db=new database1();
	@Test  //Used to identify that a method is a test method

	public void testSave()
	{
		
		assertEquals(1,database1.save());
	
		
	}
	
	
	@Test
	public void update()
	{
	
		assertEquals(1,database1.update());


	}
	
	
}