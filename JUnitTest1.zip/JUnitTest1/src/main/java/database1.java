import java.util.*;
import java.sql.*;
public class database1
{
	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","123");
		}catch(Exception e){System.out.println(e);}
		return con;
	}
	public static int save(){
		int status=0;
		try{
			Connection con=database1.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into customer(cid,cname) values (?,?)");
			System.out.println("enter customer id and name ");
			Scanner sc=new Scanner(System.in);
			 int s=sc.nextInt();
			 String name=sc.next();
				ps.setInt(1,s);
				ps.setString(2, name);
			
			 			
				status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		return status;
		
}
	
	
	public static int update(){
		int status1=0;
		try{
			Connection con=database1.getConnection();
			PreparedStatement ps=con.prepareStatement("update customer set cname=? where cid=?");
			
			System.out.println("enter customer id and name to update details ");
			Scanner sc=new Scanner(System.in);
			 int s=sc.nextInt();
			 String name=sc.next();
				ps.setInt(2,s);
				ps.setString(1, name);
			
			status1=ps.executeUpdate();
		
			
			con.close();
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
	return status1;
		
		
	}
}