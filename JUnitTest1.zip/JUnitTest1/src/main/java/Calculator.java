public class Calculator {

	public int square(int i) 
	{
		return i*i;
	}

	public String user(String string) 
	{
		
		return "sandip";
	}

	public String concat(String string, String string2) {
		
		return string+string2;
	}

	public int sub(int i, int j) {
		
		return i-j;
	}

	public int add(int i, int j) {
		
		return i+j;
	}

	public static boolean isSafe() {
		
		return false;
	}

}