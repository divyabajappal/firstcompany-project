import org.hibernate.cfg.Configuration;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class emp1 {
	
	emp1()
	{
		System.out.println("object created");
	}
	
	/*
	emp1(int id,String name, String address, String desi, String accno)
	{
	
	  gt.setEid(id);
	  gt.setName(name);
	  gt.setAddress(address);
	  gt.setDesignation(desi);
	  gt.setSalary(accno);
	}
	*/
	
	
	public void saveEmp(gettersetter1 st) {
		//Component 1
		Configuration cfg = new Configuration();
		cfg.configure();
	
		
		//component2
		
				SessionFactory ss = cfg.buildSessionFactory();
				
				//Component 3
				Session session = ss.openSession();
				//Sub-component 1 of session
				
				Transaction tx = session.beginTransaction();
				
				session.save(st);
				
				tx.commit();
				
				session.close();
				
				ss.close();
			}
		

	}

