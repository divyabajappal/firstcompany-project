

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;


import java.util.*;
public class P02_AddNewPerson {

	public static void main(String[] args) {

	
	
	 gettersetter1 s1=new gettersetter1();
          //emp1 p1 = new emp1(id, name,address,desi,accno);
		
		
	 System.out.println("enter number of account details you want to store");
		Scanner sc=new Scanner(System.in);
		int n =sc.nextInt();
		for(int i =0;i<n;i++)
		{
			System.out.println("enter customer " + (i+1)  +"details");
			System.out.println("enter  id");
			int n1=sc.nextInt();
			s1.setEid(n1);
			System.out.println("enter name");
			String name=sc.next();
			s1.setName(name);
			System.out.println("enter  Address");
			String address=sc.next();
			s1.setAddress(address);
			System.out.println("enter type of account ");
			String des=sc.next();
			s1.setDesignation(des);
			System.out.println("enter account number");
			String sal=sc.next();
			s1.setSalary(sal);
		}
		
		
		emp1 emp=new emp1();
		emp.saveEmp(s1);
		}

	}










