import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "emp_table")
public class gettersetter1 {
	//methods
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public gettersetter1() 
	{
		System.out.println(this.getClass().getSimpleName() + " created");
	}

	
	@Id
	@Column(name = "empid")
	private int eid;
	@Column(name = "name")
	private String name;
	@Column(name = "address")
	private String address;
	@Column(name = "designation")
	private String designation;
	@Column(name="Salary")
	private String salary;
	
	
}
