package com.sreesha.in.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sreesha.in.model.Login;
import com.sreesha.in.repo.EmployeeRepository;

@Service
public class ServiceInterfaceImplementation implements ServiceInterface {
	
	@Autowired
	private EmployeeRepository repo;

	public Integer saveLogin(Login employee) {
		employee = repo.save(employee);
		return employee.getId();
	}

	public List<Login> getAllEmp() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	

}
