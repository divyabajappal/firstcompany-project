package com.sreesha.in.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sreesha.in.model.Login;

public interface EmployeeRepository extends JpaRepository<Login, String> {

}
