package com.sreesha.in.service;

import java.util.List;

import com.sreesha.in.model.Login;

public interface ServiceInterface {
	
	public Integer saveLogin(Login employee);
	
	public List<Login> getAllEmp();
	


}
