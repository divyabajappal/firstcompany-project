package com.sreesha.in;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodMain{
	public static void main(String[] args) {
		SpringApplication.run(FoodMain.class, args);
	}

}
