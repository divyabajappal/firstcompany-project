package com.sreesha.in.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sreesha.in.model.Food;
import com.sreesha.in.repo.FoodRepository;

@Service
public class ServiceInterfaceImplementation implements ServiceInterface {
	
	@Autowired
	private FoodRepository repo;

	public Integer saveFood(Food foo) {
		foo= repo.save(foo);
		return foo.getId();
	}

}
