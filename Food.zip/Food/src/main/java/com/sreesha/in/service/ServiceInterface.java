package com.sreesha.in.service;

import java.util.List;

import com.sreesha.in.model.Food;

public interface ServiceInterface {
	
	public Integer saveFood(Food foo);
	
	

}
