package com.sreesha.in.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sreesha.in.model.Food;

public interface FoodRepository extends JpaRepository<Food, Integer> {

}
